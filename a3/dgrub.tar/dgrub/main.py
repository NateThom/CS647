#!/bin/python3
import json #Used to load json
from jinja2 import Environment, FileSystemLoader #Templating

def main(args):
    e = Environment(loader=FileSystemLoader('templates/'))

    template = e.get_template("base.tmpl")

    menuentry = template.render(kernel_path='/boot/kernel.1', initrd_path='/boot/initrd.1.gz')

    print(menuentry)


if __name__ == "__main__":
    args = None
    main(args)
